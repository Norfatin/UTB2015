<?php
include '../conn.php';

$connection = OpenCon();

$Order_id = $_GET['Order_id'];
$Menu_id = $_GET['Menu_id'];
$Quantity = $_GET['Quantity'];

$sql = "INSERT INTO `cart`
(`Order_id`, `Menu_id`,`Quantity`) VALUES 
('$Order_id', '$Menu_id', '$Quantity');";

if ($connection->query($sql)) {
$msg = array("status" =>1 , "msg" => "Your record inserted successfully");
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($connection);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>
