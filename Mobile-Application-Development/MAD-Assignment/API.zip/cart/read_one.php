<?php
include '../conn.php';

$connection = OpenCon();

//Select data from database
$Cart_id = $_GET['Cart_id'];

$getData = "select * from cart where `Cart_id`='$Cart_id'";
$qur = $connection->query($getData);

while($r = mysqli_fetch_assoc($qur)){

$msg[] = array(
"Cart_id" => $r['Cart_id'],
"Order_id" => $r['Order_id'], 
"Menu_id" => $r['Menu_id'], 
"Quantity" => $r['Quantity']);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>