<?php
include '../conn.php';

$connection = OpenCon();

//Update record in database
$Cart_id = $_GET['Cart_id'];
$Order_id = $_GET['Order_id'];
$Menu_id = $_GET['Menu_id'];
$Quantity = $_GET['Quantity'];

$query = "UPDATE `cart` SET 
`Order_id`='$Order_id' ,
`Menu_id`='$Menu_id' ,
`Quantity`='$Quantity'
WHERE  `Cart_id`='$Cart_id'";

if ($connection->query($query)) {
       $msg = array("status" =>1 , "msg" => "Record updated successfully");
}else {
    echo "Error: " . $query . "<br>" . mysqli_error($connention);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>
