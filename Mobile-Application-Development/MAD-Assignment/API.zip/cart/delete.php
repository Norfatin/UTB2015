<?php
include '../conn.php';

$connection = OpenCon();

//Delete record from database
$Cart_id = $_GET['Cart_id'];

$query = "DELETE FROM `cart` WHERE `Cart_id`='$Cart_id'";

if ($connection->query($query)) {
    $msg = array("status" =>1 , "msg" => "Record deleted successfully");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($connection);
} 

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>