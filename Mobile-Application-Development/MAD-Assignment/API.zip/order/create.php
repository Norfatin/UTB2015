<?php
include '../conn.php';

$connection = OpenCon();

$Table_no = $_GET['Table_no'];
$Total_price = $_GET['Total_price'];
$Order_status = $_GET['Order_status'];
$Payment_mode = $_GET['Payment_mode'];
$Timestamp = $_GET['Timestamp'];

$sql = "INSERT INTO `order_tbl`
(`Table_no`, `Total_price`,`Order_status`, `Payment_mode`, `Timestamp`) VALUES 
('$Table_no', '$Total_price', '$Order_status', '$Payment_mode', '$Timestamp');";

if ($connection->query($sql)) {
$msg = array("status" =>1 , "msg" => "Your record inserted successfully");
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($connection);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>
