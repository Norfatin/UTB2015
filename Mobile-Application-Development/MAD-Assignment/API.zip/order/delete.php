<?php
include '../conn.php';

$connection = OpenCon();

//Delete record from database
$Order_id = $_GET['Order_id'];

$query = "DELETE FROM `order_tbl` WHERE `Order_id`='$Order_id'";

if ($connection->query($query)) {
    $msg = array("status" =>1 , "msg" => "Record deleted successfully");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($connection);
} 

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>