<?php
include '../conn.php';

$connection = OpenCon();

//Update record in database
$Order_id = $_GET['Order_id'];
$Total_price = $_GET['Total_price'];
$Order_status = $_GET['Order_status'];
$Payment_mode = $_GET['Payment_mode'];
$Timestamp = $_GET['Timestamp'];

$query = "UPDATE `order_tbl` SET 
`Table_no`='$Table_no' ,
`Total_price`='$Total_price' ,
`Order_status`='$Order_status' ,
`Payment_mode`='$Payment_mode' ,
`Timestamp`='$Timestamp' 
WHERE  `Order_id`='$Order_id'";

if ($connection->query($query)) {
       $msg = array("status" =>1 , "msg" => "Record updated successfully");
}else {
    echo "Error: " . $query . "<br>" . mysqli_error($connention);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>
