<?php
include '../conn.php';

$connection = OpenCon();

//Select data from database
$Order_id = $_GET['Order_id'];

$getData = "select * from order_tbl where `Order_id`='$Order_id'";
$qur = $connection->query($getData);

while($r = mysqli_fetch_assoc($qur)){

$msg[] = array(
"Order_id" => $r['Order_id'],
"Table_no" => $r['Table_no'], 
"Total_price" => $r['Total_price'], 
"Order_status" => $r['Order_status'], 
"Payment_mode" => $r['Payment_mode'], 
"Timestamp" => $r['Timestamp']);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>