<?php
include '../conn.php';

$connection = OpenCon();

//Select data from database
$getData = "select * from employee";
$qur = $connection->query($getData);

while($r = mysqli_fetch_assoc($qur)){
$msg[] = array(
"Employee_id" => $r['Employee_id'],
"Employee_email" => $r['Employee_email'], 
"Employee_password" => $r['Employee_password']);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>