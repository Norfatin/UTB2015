<?php
include '../conn.php';

$connection = OpenCon();

//Update record in database
$Employee_id = $_GET['Employee_id'];
$Employee_email = $_GET['Employee_email'];
$Employee_password = $_GET['Employee_password'];

$query = "UPDATE `employee` SET 
`Employee_email`='$Employee_email',
`Employee_password`='$Employee_password'
WHERE  `Employee_id`='$Employee_id'";

if ($connection->query($query)) {
       $msg = array("status" =>1 , "msg" => "Record updated successfully");
}else {
    echo "Error: " . $query . "<br>" . mysqli_error($connention);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>