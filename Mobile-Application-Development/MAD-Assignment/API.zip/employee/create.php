<?php
include '../conn.php';

$connection = OpenCon();

$Employee_email = $_GET['Employee_email'];
$Employee_password = $_GET['Employee_password'];

$query = "INSERT INTO `employee`
(`Employee_email`, `Employee_password`) VALUES 
('$Employee_email', '$Employee_password');";

if ($connection->query($query)) {
$msg = array("status" =>1 , "msg" => "Your record inserted successfully");
} else {
echo "Error: " . $query . "<br>" . mysqli_error($connection);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>
