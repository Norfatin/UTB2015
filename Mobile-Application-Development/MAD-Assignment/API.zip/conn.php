<?php

function OpenCon()
 {
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "";
 $db = "moosdb1";
 
$connection = new mysqli($dbhost, $dbuser, $dbpass, $db) or die(mysqli_error());

return $connection;
 }
 
?>