<?php
include '../conn.php';

$connection = OpenCon();

$Name = $_GET['Name'];
$Price = $_GET['Price'];
$Description = $_GET['Description'];
$Image = $_GET['Image'];

$sql = "INSERT INTO `menu`
(`Name`, `Price`, `Description`, `Image`) VALUES 
('$Name', '$Price', '$Description', '$Image');";

if ($connection->query($sql)) {
$msg = array("status" =>1 , "msg" => "Your record was inserted successfully");
} else {
echo "Error: " . $sql . "<br>" . mysqli_error($connection);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>
