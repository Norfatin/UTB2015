<?php
include '../conn.php';

$connection = OpenCon();

//Delete record from database
$Menu_id = $_GET['Menu_id'];

$query = "DELETE FROM `menu` WHERE `Menu_id`='$Menu_id'";

if ($connection->query($query)) {
    $msg = array("status" =>1 , "msg" => "Record deleted successfully");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($connection);
} 

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>