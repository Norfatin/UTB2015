<?php
include '../conn.php';

$connection = OpenCon();

//Update record in database
$Menu_id = $_GET['Menu_id'];
$Name = $_GET['Name'];
$Price = $_GET['Price'];
$Description = $_GET['Description'];
$Image = $_GET['Image'];

$query = "UPDATE `menu` SET 
`Name`='$Name' ,
`Price`='$Price',
`Description`='$Description',
`Image`='$Image'
WHERE  `Menu_id`='$Menu_id'";

if ($connection->query($query)) {
       $msg = array("status" =>1 , "msg" => "Record updated successfully");
}else {
    echo "Error: " . $query . "<br>" . mysqli_error($connention);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>