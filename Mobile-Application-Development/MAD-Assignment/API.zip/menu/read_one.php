<?php
include '../conn.php';

$connection = OpenCon();

//Select data from database
$Menu_id = $_GET['Menu_id'];

$getData = "select * from menu where `Menu_id`='$Menu_id'";
$qur = $connection->query($getData);

while($r = mysqli_fetch_assoc($qur)){

$msg[] = array(
"Menu_id" => $r['Menu_id'],
"Name" => $r['Name'], 
"Price" => $r['Price'],
"Description" => $r['Description'],
"Image" => $r['Image']);
}

header('content-type: application/json');
echo json_encode($msg);

@mysqli_close($connection);

?>