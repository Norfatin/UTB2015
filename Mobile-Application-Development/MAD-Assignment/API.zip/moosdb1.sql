-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 23, 2019 at 06:28 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moosdb1`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `Cart_id` int(11) NOT NULL,
  `Order_id` int(11) NOT NULL,
  `Menu_id` int(11) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`Cart_id`, `Order_id`, `Menu_id`, `Quantity`) VALUES
(1, 1, 28, 2),
(2, 1, 18, 2),
(3, 1, 10, 1),
(4, 1, 21, 1),
(5, 1, 23, 1),
(6, 2, 10, 3),
(7, 3, 26, 1),
(8, 3, 1, 1),
(9, 4, 2, 1),
(10, 5, 7, 1),
(11, 5, 9, 1),
(12, 5, 14, 1);

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `Customer_id` int(11) NOT NULL,
  `Customer_email` varchar(255) NOT NULL,
  `Customer_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`Customer_id`, `Customer_email`, `Customer_password`) VALUES
(1, 'darbous@hotmail.com', 'test123'),
(2, 'dany@hotmail.com', '432fgvr'),
(3, 'vivien2@gmail.com', '987654321m');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `Employee_id` int(11) NOT NULL,
  `Employee_email` varchar(255) NOT NULL,
  `Employee_password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`Employee_id`, `Employee_email`, `Employee_password`) VALUES
(1, 'Aziz@moos.com', 'Az$z987'),
(2, 'Salmah@moos.com', 'Admin123'),
(3, 'Mary@moos.com', 'Us3r1'),
(4, 'Danny@moos.com', '564danny');

-- --------------------------------------------------------

--
-- Table structure for table `ingredients`
--

CREATE TABLE `ingredients` (
  `Ingredients_id` int(11) NOT NULL,
  `Ingredients_Name` varchar(255) NOT NULL,
  `Ingredients_Price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ingredients`
--

INSERT INTO `ingredients` (`Ingredients_id`, `Ingredients_Name`, `Ingredients_Price`) VALUES
(1, 'Olive Oil', 2),
(2, 'Tomato Sauce', 2),
(3, 'Mayonnaise', 2),
(4, 'Honey', 2),
(5, 'Full Cream', 2),
(6, 'Mozzarella', 2),
(7, 'Parmesan', 2),
(8, 'Cheddar', 3),
(9, 'Colby Cheese', 3),
(10, 'Goat Cheese', 3),
(11, 'Mixed Cheese', 3),
(12, 'Onions', 2),
(13, 'Capsicum', 2),
(14, 'Fresh Mushroom', 3),
(15, 'Basil', 2),
(16, 'Eggplant', 4),
(17, 'Jalapeno', 3),
(18, 'Pineapple', 4),
(19, 'Olive', 2),
(20, 'Sesame Seeds', 2),
(21, 'Mixed Onions', 2),
(22, 'Honey Garlic Chicken', 6),
(23, 'BBQ Chicken', 5),
(24, 'Chicken Ham', 5),
(25, 'Spicy Chicken', 5),
(26, 'Pepperoni', 4),
(27, 'Meatball', 6),
(28, 'Beef Rashers', 4),
(29, 'Beef Jerky', 4),
(30, 'Tuna', 4),
(31, 'Smoked Salmon', 8);

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `Menu_id` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Price` decimal(11,0) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`Menu_id`, `Name`, `Price`, `Description`, `Image`) VALUES
(1, 'Honey Garlic Chicken Pizza', '19', 'Honey Garlic Chicken\r\nMozzarella\r\nSesame Seeds\r\n\r\n', 'http://192.168.100.6/Mooswebservice/menu/honeygarlicchicken.jpg'),
(2, 'Pepperoni Pizza', '19', 'Pepperoni\r\nTomato Sauce\r\nMozzarella', 'http://192.168.100.6/Mooswebservice/menu/pepperoni.jpg'),
(3, 'Meatlover Pizza', '22', 'Beef Jerky\r\nBeef Rashers\r\nMeatball\r\nPepperoni\r\nMozzarella', 'http://192.168.100.6/Mooswebservice/menu/meatlover.jpg'),
(4, 'Meatball Pizza', '22', 'Meatball\r\nTomato Sauce\r\nMozzarella', 'http://192.168.100.6/Mooswebservice/menu/meatball.jpg'),
(5, 'Americana Pizza', '22', 'Pepperoni\r\nMayonnaise\r\nCapsicum\r\nFresh Mushroom\r\nMozzarella', 'http://192.168.100.6/Mooswebservice/menu/americana.jpg'),
(6, 'California Pizza', '22', 'Beef Rashers\r\nMeatball\r\nOlive\r\nFresh Mushroom\r\nPineapple\r\nMozzarella', 'http://192.168.100.6/Mooswebservice/menu/california.jpg'),
(7, 'Tuna Pizza', '19', 'Tuna\r\nPineapple\r\nSesame Seeds\r\nFresh Mushroom\r\nCapsicum\r\nMozzarella', 'http://192.168.100.6/Mooswebservice/menu/tuna.jpg'),
(8, 'Smoked Salmon Pizza', '22', 'Smoked Salmon\r\nOlive\r\nMayonnaise\r\nCapsicum\r\nColby Cheese\r\n\r\n\r\n', 'http://192.168.100.6/Mooswebservice/menu/smokedsalmon.jpg'),
(9, 'Crispy Beef Jerky Pizza', '22', 'Beef Jerky\r\nMixed Onions\r\nMozzrella', 'http://192.168.100.6/Mooswebservice/menu/crispybeefjerky.jpg'),
(10, 'Margarita Pizza', '18', 'Tomato Sauce\r\nBasil\r\nFresh Mushroom\r\nMozzarella', 'http://192.168.100.6/Mooswebservice/menu/margherita.jpg'),
(11, 'Ratatouille Pizza', '19', 'Tomato Sauce\r\nEggplant\r\nMayonnaise\r\nCapsicum\r\nColby Cheese', 'http://192.168.100.6/Mooswebservice/menu/ratatouille.jpg'),
(12, 'Al-Funghi Pizza', '19', 'Fresh Mushroom\r\nCapsicum\r\nJalapeno\r\nMixed Onions\r\nGoat Cheese', 'http://192.168.100.6/Mooswebservice/menu/alfunghi.jpg'),
(13, '4Cheese Pizza', '19', 'Tomato Sauce\r\nFull Cream\r\nHoney\r\nParmesan\r\nCheddar\r\nColby Cheese\r\nGoat Cheese\r\n\r\n', 'http://192.168.100.6/Mooswebservice/menu/4cheese.jpg'),
(14, 'Cream Cheese Pizza', '19', 'Full Cream\r\nHoney\r\nMozzarella\r\nMixed Cheese', 'http://192.168.100.6/Mooswebservice/menu/creamcheese.jpg'),
(15, 'BBQ Chicken Pizza', '19', 'BBQ Chicken\r\nJalapeno\r\nCapsicum\r\nMixed Onions\r\nMozzarella', 'http://192.168.100.6/Mooswebservice/menu/bbqchicken.jpg'),
(16, 'Honolulu Pizza', '19', 'Spicy Chicken\r\nPineapple\r\nCapsicum\r\nMayonnaise\r\nMozzarella', 'http://192.168.100.6/Mooswebservice/menu/honolulu.jpg'),
(17, 'Ham & Cheese Pizza', '19', 'Chicken Ham\r\nPineapple\r\nHoney\r\nMixed Cheese', 'http://192.168.100.6/Mooswebservice/menu/hamcheese.jpg'),
(18, 'BBQ Vs Buffalo Pizza', '22', 'BBQ Chicken\r\nMeatball\r\nJalapeno\r\nCapsicum\r\nMozzarella\r\nJalapeno', 'http://192.168.100.6/Mooswebservice/menu/bbqvsbuffalo.jpg'),
(19, 'Buffalo Chicken Pizza', '19', 'Spicy Chicken\r\nChicken Ham\r\nBeef Rashers\r\nBeef Jerky\r\nMixed Onions\r\nMozzarella', 'http://192.168.100.6/Mooswebservice/menu/buffalochicken.jpg'),
(20, 'Calzone', '22', 'Chicken Ham and Beef Rashers Calzone', 'http://192.168.100.6/Mooswebservice/menu/calzone.jpg'),
(21, 'Barbican Drink', '3', 'Barbican Drink', 'http://192.168.100.6/Mooswebservice/menu/barbicandrink.jpg'),
(22, 'Coconut Water', '3', 'Coconut Water', 'http://192.168.100.6/Mooswebservice/menu/coconutwater.jpg'),
(23, 'BBQ Wings', '5', 'BBQ Chicken Wings', 'http://192.168.100.6/Mooswebservice/menu/bbqwings.jpg'),
(24, 'Hot Wings', '5', 'Hot Chicken Wings', 'http://192.168.100.6/Mooswebservice/menu/hotwings.jpg'),
(25, 'Garden Salad', '5', 'Garden Salad', 'http://192.168.100.6/Mooswebservice/menu/gardensalad.jpg'),
(26, 'Chicken Curry Puff', '3', 'Chicken Curry Puff', 'http://192.168.100.6/Mooswebservice/menu/chickencurrypuff.jpg'),
(27, 'Cinnamon Whirl', '3', 'Cinnamon bun', 'http://192.168.100.6/Mooswebservice/menu/cinnamonwhirl.jpg'),
(28, 'Space Meatballs with Mashed Potato', '5', 'Meatballs with Mashed Potato', 'http://192.168.100.6/Mooswebservice/menu/spacemeatballswithmashedpotato.jpg'),
(29, 'DIY Pizza', '22', 'Create your own pizza!', 'http://192.168.100.6/Mooswebservice/menu/diypizza.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `order_tbl`
--

CREATE TABLE `order_tbl` (
  `Order_id` int(11) NOT NULL,
  `Table_no` int(11) NOT NULL,
  `Total_price` int(255) NOT NULL,
  `Order_status` varchar(255) NOT NULL,
  `Payment_mode` varchar(255) NOT NULL,
  `Timestamp` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_tbl`
--

INSERT INTO `order_tbl` (`Order_id`, `Table_no`, `Total_price`, `Order_status`, `Payment_mode`, `Timestamp`) VALUES
(1, 1, 80, 'Paid', 'cash', '2017-10-28 12:22:36'),
(2, 2, 54, 'Served', 'cash', '2017-10-28 12:27:16'),
(3, 3, 22, 'Ready For Serving', 'cash', '2017-10-28 14:25:23'),
(4, 4, 19, 'Pending', 'cash', '2017-10-28 14:28:29'),
(5, 1, 60, 'Pending', 'cash', '2017-11-06 19:40:34');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`Cart_id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`Customer_id`),
  ADD UNIQUE KEY `Customer_email` (`Customer_email`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`Employee_id`);

--
-- Indexes for table `ingredients`
--
ALTER TABLE `ingredients`
  ADD PRIMARY KEY (`Ingredients_id`),
  ADD UNIQUE KEY `Ingredients_Name` (`Ingredients_Name`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`Menu_id`);

--
-- Indexes for table `order_tbl`
--
ALTER TABLE `order_tbl`
  ADD PRIMARY KEY (`Order_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `Cart_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `Customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `employee`
--
ALTER TABLE `employee`
  MODIFY `Employee_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `ingredients`
--
ALTER TABLE `ingredients`
  MODIFY `Ingredients_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `Menu_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `order_tbl`
--
ALTER TABLE `order_tbl`
  MODIFY `Order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
